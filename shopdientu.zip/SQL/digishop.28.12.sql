-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 27, 2022 lúc 06:14 PM
-- Phiên bản máy phục vụ: 10.4.22-MariaDB
-- Phiên bản PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `digishop`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `branch`
--

CREATE TABLE `branch` (
  `BRANCH_ID` int(11) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ADDRESS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HOTLINE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `branch`
--

INSERT INTO `branch` (`BRANCH_ID`, `NAME`, `ADDRESS`, `HOTLINE`) VALUES
(2, 'Ha Noi', '325 Cau Giay', '099999999'),
(15, 'DN', '241 Xuân Thủy, Cầu Giấy, hà Nội', '11111');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `brand`
--

CREATE TABLE `brand` (
  `BRAND_ID` int(11) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COUNTRY` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `brand`
--

INSERT INTO `brand` (`BRAND_ID`, `NAME`, `COUNTRY`) VALUES
(1, 'APPLE', 'USA'),
(2, 'SAMSUNG', 'KOREA'),
(3, 'LG', 'KOREA'),
(5, 'XIAOMI', 'CHINA'),
(6, 'HUAWEI', 'CHINA'),
(8, 'VIVO', 'CHINA'),
(10, 'Asus', 'Taiwan'),
(11, 'Acer', 'Taiwan'),
(12, 'Gigabyte', 'Taiwan'),
(13, 'DELL', 'USA'),
(14, 'NOKIA', 'PLA'),
(15, 'AVA+', 'CHINA');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `CATEGORY_ID` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `NAME`, `CODE`) VALUES
(4, 'PHONE', 1000),
(5, 'TABLET', 1001),
(6, 'LAPTOP', 1002),
(7, 'SMART WATCH', 1003),
(8, 'ACCESSORY', 1004);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `deviceos`
--

CREATE TABLE `deviceos` (
  `DEVICEOS_ID` int(11) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VERSION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `deviceos`
--

INSERT INTO `deviceos` (`DEVICEOS_ID`, `NAME`, `VERSION`) VALUES
(1, 'Andoid', '9.0'),
(2, 'IOS', '12'),
(5, 'Blackberry OS', '1002'),
(6, 'Palm OS', '5.0'),
(7, 'Windows', '10'),
(8, 'Windows', '11'),
(9, 'Mac', '13-Ventura'),
(10, 'Ubuntu', '22.04'),
(11, 'NONE', 'NONE');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(11) NOT NULL,
  `FNAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MNAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LNAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BOD` date DEFAULT NULL,
  `ADDRESS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GENDER` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FNAME`, `MNAME`, `LNAME`, `BOD`, `ADDRESS`, `PHONE`, `GENDER`) VALUES
(1, 'Pham', 'Van ', 'Minh', '1991-03-26', 'Cau Giay -Ha Noi', '0888888888', 'Male'),
(2, 'Trần', 'Thị ', 'Dung', '1995-11-12', 'Hà Trung - Thanh Hóa', '0932445655', 'Male');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `galery`
--

CREATE TABLE `galery` (
  `GALERY_ID` int(11) NOT NULL,
  `PRODUCT_ID` int(11) DEFAULT NULL,
  `DIR` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILENAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CREATE_AT` datetime NOT NULL,
  `UPDATE_AT` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `galery`
--

INSERT INTO `galery` (`GALERY_ID`, `PRODUCT_ID`, `DIR`, `FILENAME`, `CREATE_AT`, `UPDATE_AT`) VALUES
(18, 5, './assets/img/phone/', 'iphone-11-trang-600x600.jpg', '2022-12-14 16:44:50', '0000-00-00 00:00:00'),
(19, 7, './assets/img/phone/', 'samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '2022-12-14 16:54:11', '0000-00-00 00:00:00'),
(20, 9, './assets/img/laptop/', 'asus-zenbook-14-oled-ux3402za-i5-km218w-thumb-600x600.jpg', '2022-12-14 16:54:38', '0000-00-00 00:00:00'),
(21, 12, './assets/img/smartwatch/', 'dong-ho-thong-minh-xiaomi-watch-s1-thumbn-600x600.jpg', '2022-12-14 16:54:57', '0000-00-00 00:00:00'),
(22, 13, './assets/img/tablet/', 'samsung-galaxy-tab-a7-lite-gray-600x600.jpg', '2022-12-14 16:55:10', '0000-00-00 00:00:00'),
(24, 8, './assets/img/phone/', 'Xiaomi-redmi-note-11-black-600x600.jpeg', '2022-12-17 16:06:51', '0000-00-00 00:00:00'),
(25, 10, './assets/img/phone/', 'oppo-reno8-pro-thumb-xanh-1-600x600.jpg', '2022-12-17 16:07:04', '0000-00-00 00:00:00'),
(26, 14, './assets/img/phone/', 'nokia-5710-thumb-den-1-600x600.jpg', '2022-12-17 16:10:02', '0000-00-00 00:00:00'),
(27, 15, './assets/img/phone/', 'iphone-13-pro-max-xanh-la-thumb-600x600.jpg', '2022-12-20 12:11:16', '0000-00-00 00:00:00'),
(32, 11, './assets/img/laptop/', 'apple-macbook-air-2020-mgn63saa-(14).jpg', '2022-12-27 02:43:34', '0000-00-00 00:00:00'),
(33, 16, './assets/img/accessory/', 'ava-lj-jp199-thumb-600x600.jpeg', '2022-12-27 09:32:40', '0000-00-00 00:00:00'),
(34, 17, './assets/img/accessory/', 'polymer-10000-mah-type-c-esaver-pj-jp106s-600x600.jpeg', '2022-12-27 09:38:17', '0000-00-00 00:00:00'),
(35, 18, './assets/img/phone/', 'samsung-galaxy-a04s-(2).jpg', '2022-12-27 14:26:28', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `list_product`
--

CREATE TABLE `list_product` (
  `LIST_PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `BRANCH_ID` int(11) DEFAULT NULL,
  `CREATE_AT` datetime DEFAULT NULL,
  `UPDATE_AT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `logins`
--

CREATE TABLE `logins` (
  `logins_id` int(11) NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `passwd` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `position` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `logins`
--

INSERT INTO `logins` (`logins_id`, `username`, `passwd`, `position`) VALUES
(1, 'c1001', 'namhau', 'admin'),
(10, 'c1003', 'namhau', 'admin'),
(13, 'c1002', 'namhau', 'admin');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `DEVICEOS_ID` int(11) DEFAULT NULL,
  `BRAND_ID` int(11) NOT NULL,
  `PRICE` int(11) DEFAULT NULL,
  `DISCOUNT` int(11) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `CREATE_AT` datetime DEFAULT NULL,
  `UPDATE_AT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `NAME`, `CATEGORY_ID`, `DEVICEOS_ID`, `BRAND_ID`, `PRICE`, `DISCOUNT`, `DESCRIPTION`, `CREATE_AT`, `UPDATE_AT`) VALUES
(5, 'iPhone 11 ', 4, 2, 1, 11690000, 0, 'Apple đã chính thức trình làng bộ 3 siêu phẩm iPhone 11, trong đó phiên bản iPhone 11 64GB có mức giá rẻ nhất nhưng vẫn được nâng cấp mạnh mẽ như iPhone Xr ra mắt trước đó.', '2022-12-11 00:00:00', '2022-12-14 12:26:34'),
(7, 'Sam sung Talaxy b Flip4', 4, 1, 2, 19190000, 0, 'Samsung Galaxy Z Flip4 128GB đã chính thức ra mắt thị trường công nghệ, đánh dấu sự trở lại của Samsung trên con đường định hướng người dùng về sự tiện lợi trên những chiếc điện thoại gập.', '2022-12-12 00:00:00', '0000-00-00 00:00:00'),
(8, ' Xiaomi Redmi Note 11 ', 4, 1, 5, 4490000, 0, 'Điện thoại Redmi được mệnh danh là dòng sản phẩm quốc dân ngon - bổ  - rẻ của Xiaomi và Redmi Note 11 (4GB/64GB) cũng không phải ngoại lệ, máy sở hữu một hiệu năng ổn định, màn hình 90 Hz mượt mà, cụm camera AI đến 50 MP cùng một mức giá vô cùng tốt.', '2022-12-12 15:43:31', '0000-00-00 00:00:00'),
(9, 'Asus-zenbook-14-oled-ux3402za-i5-km218w', 6, 8, 10, 32999999, 0, 'Laptop siêu mỏng nhẹ, màn hình oled siêu đẹp.', '2022-12-13 09:01:38', '0000-00-00 00:00:00'),
(10, 'Oppo reno8 pro', 4, 1, 6, 6899999, 1, 'OPPO Reno8 Pro 5G là chiếc điện thoại cao cấp được nhà OPPO ra mắt vào thời điểm 09/2022, máy hướng đến sự hoàn thiện cao cấp ở phần thiết kế cùng khả năng quay chụp chuyên nghiệp nhờ trang bị vi xử lý hình ảnh MariSilicon X chuyên dụng.', '2022-12-13 10:11:04', '2022-12-26 14:27:34'),
(11, 'MacBook Pro 14 M1 Pro 2021', 6, 9, 1, 42990000, 0, 'Apple đã giới thiệu MacBook Pro 14 inch vào tháng 10/2021, mang một diện mạo mới cùng bộ vi xử lý do hãng tự phát triển, không chỉ cho hiệu năng vượt trội mà còn sở hữu màn hình với khả năng hiển thị thực sự ấn tượng, khiến mình mê mẩn khi cầm trên tay trải nghiệm.', '2022-12-13 11:13:13', '0000-00-00 00:00:00'),
(12, 'Xiaomi watch s1', 7, 1, 5, 1560000, 0, 'Đồng hồ thông minh của xiaomi, pin sử dụng 20 ngày.', '2022-12-13 11:41:43', '0000-00-00 00:00:00'),
(13, 'Samsung Galaxy Tab A7 lite', 5, 1, 2, 6900000, 0, 'Máy tính bảng Samsung Galaxy Tab A7 Lite là phiên bản rút gọn của dòng tablet \"ăn khách\" Galaxy Tab A7 thuộc thương hiệu Samsung, đáp ứng nhu cầu giải trí của khách hàng thuộc phân khúc bình dân với màn hình lớn nhưng vẫn gọn nhẹ hợp túi tiền.', '2022-12-14 12:46:40', '0000-00-00 00:00:00'),
(14, 'Nokia 5710', 4, 1, 14, 1790000, 0, 'Bên cạnh sự phát triển của điện thoại thông minh thì điện thoại phổ thông cũng không hề kém cạnh khi xuất hiện ngày càng nhiều kiểu thiết kế độc đáo. Cụ thể như chiếc Nokia 5710 - máy được trang bị tai nghe không dây ngay tại mặt lưng, điều này giúp máy không chỉ dành cho nghe gọi mà còn có thể hoạt động như một thiết bị nghe nhạc.', '2022-12-17 16:09:20', '0000-00-00 00:00:00'),
(15, 'Iphone 14', 4, 2, 1, 23000000, 0, 'iPhone 14 Pro Max là mẫu flagship nổi bật nhất của Apple trong lần trở lại năm 2022 với nhiều cải tiến về công nghệ cũng như vẻ ngoài cao cấp, sang chảnh hợp với gu thẩm mỹ đại chúng. ', '2022-12-20 12:10:23', '2022-12-26 21:28:52'),
(16, 'Pin sạc dự phòng 7500 mAh AVA+ LJ JP199', 8, 11, 15, 175000, 0, 'Thiết kế thời trang, nhỏ nhắn, dễ mang theo.\r\nSử dụng lõi pin Li-Ion an toàn, bền tốt.\r\nNguồn ra có 2 cổng USB 5V – 2A.\r\nDung lượng 7500 mAh cho hiệu suất sạc 64%.\r\nSạc được cho mọi điện thoại và máy tính bảng tương thích.', '2022-12-26 16:09:44', '0000-00-00 00:00:00'),
(17, 'Pin sạc dự phòng Polymer 10.000 mAh Type C eSaver ', 8, 11, 15, 600000, 0, 'Thiết kế vỏ nhôm chắc chắn, màu sắc trang nhã.\r\nDung lượng pin 10.000 mAh, hiệu suất sạc đến 62.5%.\r\n2 cổng sạc ra USB 5V - 2A và Type-C 5V - 2A, sạc đồng thời 2 cổng cho 5V - 2.4A.\r\nSử dụng lõi pin Polymer chất lượng cao, tăng khả năng dùng được lâu và an toàn.\r\nTrang bị thêm cổng ra/vào Type-C thích hợp cho các thiết bị có cổng kết nối Type-C.\r\nTương thích với nhiều thiết bị điện thoại, máy tính bảng', '2022-12-26 16:16:24', '0000-00-00 00:00:00'),
(18, 'Samsung Galaxy A04s', 4, 1, 2, 3990000, 0, 'Samsung Galaxy A04s mang nhiều cải tiến so với thế hệ Galaxy A03s, màn hình hỗ trợ tần số quét 90 Hz cho trải nghiệm mượt mà cùng camera độ phân giải lên đến 50 MP để bạn nhiếp ảnh thêm tự tin, hứa hẹn mang đầy đủ các tính năng cần thiết ở một chiếc điện thoại dòng A giá rẻ.', '2022-12-27 14:26:06', '0000-00-00 00:00:00');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`BRANCH_ID`);

--
-- Chỉ mục cho bảng `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`BRAND_ID`);

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CATEGORY_ID`);

--
-- Chỉ mục cho bảng `deviceos`
--
ALTER TABLE `deviceos`
  ADD PRIMARY KEY (`DEVICEOS_ID`);

--
-- Chỉ mục cho bảng `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`);

--
-- Chỉ mục cho bảng `galery`
--
ALTER TABLE `galery`
  ADD PRIMARY KEY (`GALERY_ID`),
  ADD KEY `FK_GALERY_PRODUCT_ID` (`PRODUCT_ID`);

--
-- Chỉ mục cho bảng `list_product`
--
ALTER TABLE `list_product`
  ADD PRIMARY KEY (`LIST_PRODUCT_ID`),
  ADD KEY `FK_LIST_PRODUCT_PRODUCT_ID` (`PRODUCT_ID`),
  ADD KEY `FK_LIST_PRODUCT_BRANCH_ID` (`BRANCH_ID`);

--
-- Chỉ mục cho bảng `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`logins_id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `FK_PRODUCT_CATEGORY` (`CATEGORY_ID`),
  ADD KEY `FK_Product_OS` (`DEVICEOS_ID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `branch`
--
ALTER TABLE `branch`
  MODIFY `BRANCH_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `brand`
--
ALTER TABLE `brand`
  MODIFY `BRAND_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `category`
--
ALTER TABLE `category`
  MODIFY `CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `deviceos`
--
ALTER TABLE `deviceos`
  MODIFY `DEVICEOS_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `employee`
--
ALTER TABLE `employee`
  MODIFY `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `galery`
--
ALTER TABLE `galery`
  MODIFY `GALERY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT cho bảng `list_product`
--
ALTER TABLE `list_product`
  MODIFY `LIST_PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `logins`
--
ALTER TABLE `logins`
  MODIFY `logins_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `galery`
--
ALTER TABLE `galery`
  ADD CONSTRAINT `FK_GALERY_PRODUCT_ID` FOREIGN KEY (`PRODUCT_ID`) REFERENCES `product` (`PRODUCT_ID`);

--
-- Các ràng buộc cho bảng `list_product`
--
ALTER TABLE `list_product`
  ADD CONSTRAINT `FK_LIST_PRODUCT_BRANCH_ID` FOREIGN KEY (`BRANCH_ID`) REFERENCES `branch` (`BRANCH_ID`),
  ADD CONSTRAINT `FK_LIST_PRODUCT_PRODUCT_ID` FOREIGN KEY (`PRODUCT_ID`) REFERENCES `product` (`PRODUCT_ID`);

--
-- Các ràng buộc cho bảng `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_PRODUCT_CATEGORY` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `FK_Product_Brand` FOREIGN KEY (`BRAND_ID`) REFERENCES `brand` (`BRAND_ID`),
  ADD CONSTRAINT `FK_Product_OS` FOREIGN KEY (`DEVICEOS_ID`) REFERENCES `deviceos` (`DEVICEOS_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
