<?php
    if(isset($_COOKIE["SSID"])) {
        setcookie("SSID",$_COOKIE["PSSID"], time() - 60, "/");
        header("location: login.php");
    } else {
        header("location: login.php");
    }




?>